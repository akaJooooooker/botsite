const express = require('express')
const app = express()
const port = 3000

// 指定靜態資源目錄
app.use(express.static('public'));

// 將pug設置為渲染引擎
app.set('view engine', 'pug');

// 指定模板存放的路徑
app.set('views', './views');

app.get('/', (req, res) => {
    res.render('index', { title: 'My Bot Website', message: 'Welcome to my bot website!' });
});

app.get('/about', (req, res) => {
    res.render('about');
});

app.route('/contact')
    .get((req, res) => {
        res.render('contact');
    })
    .post((req, res) => {
        res.send('Thanks for your message!');
    });


app.listen(port, () => console.log(`Example app listening at http://localhost:${port}`))